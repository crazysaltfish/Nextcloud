package lecho.lib.hellocharts.listener;


import lecho.lib.hellocharts.model.BubbleValue;

public class DummyBubbleChartOnValueSelectListener implements BubbleChartOnValueSelectListener {

    @Override
    public void onValueSelected(int bubbleIndex, BubbleValue value) {

    }

    @Override
    public void onValueDeselected() {

    }
}
