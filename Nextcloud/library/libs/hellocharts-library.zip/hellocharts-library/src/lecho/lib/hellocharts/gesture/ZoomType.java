package lecho.lib.hellocharts.gesture;

public enum ZoomType {

    HORIZONTAL, VERTICAL, HORIZONTAL_AND_VERTICAL;
}
